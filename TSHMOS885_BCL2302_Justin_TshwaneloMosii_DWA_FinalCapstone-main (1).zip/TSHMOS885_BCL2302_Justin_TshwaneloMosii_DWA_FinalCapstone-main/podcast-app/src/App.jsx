import React, { useEffect, useState } from 'react';
import PodcastList from './components/PodcastList'



function App () {//component initializes several state variables using the `useState` hook5t
 return(
  <PodcastList />
 )
 }
export default App;